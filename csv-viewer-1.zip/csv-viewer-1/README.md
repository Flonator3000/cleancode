java -cp ./target/classes com.example.csvviewer1.CsvViewer1Application
