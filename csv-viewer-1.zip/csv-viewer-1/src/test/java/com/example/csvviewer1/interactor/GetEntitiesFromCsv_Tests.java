package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Entity;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

public class GetEntitiesFromCsv_Tests {

    @Test
    void getPersonsFromCsv_validCsv_correctResponse() throws IOException {
        String filePath = "src/test/resources/persons.csv";

        ArrayList<Entity> entities = GetEntitiesFromCsv.execute(filePath);

        assertEquals(entities.size(), 7);
        assertEquals(entities.get(0).getCells().get(0), "Peter");
        assertEquals(entities.get(1).getCells().get(1), "57");
        assertEquals(entities.get(2).getCells().get(2), "Munich");
    }

}
