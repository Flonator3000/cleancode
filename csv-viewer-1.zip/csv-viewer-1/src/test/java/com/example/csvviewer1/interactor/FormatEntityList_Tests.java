package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Entity;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class FormatEntityList_Tests {

    @Test
    void formatEntityList_inputEntities_correctResponse() {
        ArrayList<Entity> entities = new ArrayList<>();
        Entity entity1 = new Entity(new ArrayList<String>(Arrays.asList("Peter", "42", "New York")), new ArrayList<>(Arrays.asList("Name", "Age", "City")));
        Entity entity2 = new Entity(new ArrayList<String>(Arrays.asList("Paul", "57", "London")), new ArrayList<>(Arrays.asList("Name", "Age", "City")));
        Entity entity3 = new Entity(new ArrayList<String>(Arrays.asList("Mary", "35", "Munich")), new ArrayList<>(Arrays.asList("Name", "Age", "City")));
        entities.add(entity1);
        entities.add(entity2);
        entities.add(entity3);

        String result = FormatEntityList.execute(entities);

        String expectedResult = "Name |Age|City    |\n" +
                "-----+---+--------+\n" +
                "Peter|42 |New York|\n" +
                "Paul |57 |London  |\n" +
                "Mary |35 |Munich  |";
        assertEquals(result, expectedResult);
    }

}
