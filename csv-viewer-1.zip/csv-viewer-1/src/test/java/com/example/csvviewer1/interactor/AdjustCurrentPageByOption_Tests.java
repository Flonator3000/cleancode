package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Option;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AdjustCurrentPageByOption_Tests {

    @Test
    void adjustCurrentPageByOption_previousPageChosen_correctResult() {
        int currentPage = 2;
        Option option = Option.PREVIOUS_PAGE;

        int udaptedPage = AdjustCurrentPageByOption.execute(option, currentPage, Integer.MAX_VALUE);

        assertEquals(udaptedPage, 1);
    }

    @Test
    void adjustCurrentPageByOption_previousPageChosenWhenOnLowerBorder_noOverflowHappened() {
        int currentPage = 0;
        Option option = Option.PREVIOUS_PAGE;

        int udaptedPage = AdjustCurrentPageByOption.execute(option, currentPage, Integer.MAX_VALUE);

        assertEquals(udaptedPage, 0);
    }

    @Test
    void adjustCurrentPageByOption_nextPageChosen_correctResult() {
        int currentPage = 2;
        Option option = Option.NEXT_PAGE;

        int udaptedPage = AdjustCurrentPageByOption.execute(option, currentPage, Integer.MAX_VALUE);

        assertEquals(udaptedPage, 3);
    }

    @Test
    void adjustCurrentPageByOption_nextPageChosenWhenOnUpperBorder_noOverflowHappened() {
        int currentPage = 2;
        Option option = Option.NEXT_PAGE;

        int udaptedPage = AdjustCurrentPageByOption.execute(option, currentPage, 2);

        assertEquals(udaptedPage, 2);
    }

    @Test
    void adjustCurrentPageByOption_firstPageChosen_correctResult() {
        int currentPage = 2;
        Option option = Option.FIRST_PAGE;

        int udaptedPage = AdjustCurrentPageByOption.execute(option, currentPage, 2);

        assertEquals(udaptedPage, 0);
    }

    @Test
    void adjustCurrentPageByOption_lastPageChosen_correctResult() {
        int currentPage = 0;
        Option option = Option.LAST_PAGE;

        int udaptedPage = AdjustCurrentPageByOption.execute(option, currentPage, 2);

        assertEquals(udaptedPage, 2);
    }

}
