package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Entity;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class GetEntitiesFromCsv {


    public static ArrayList<Entity> execute(String filepath) throws IOException {
        final String delimiter = ";";
        String line = "";

        ArrayList<Entity> entities = new ArrayList<>();
        String[] headlines = null;

        FileReader fileReader = new FileReader(filepath);
        BufferedReader reader = new BufferedReader(fileReader);
        boolean skippedHeadline = false;
        while ((line = reader.readLine()) != null) {
            if (!skippedHeadline) {
                headlines = line.split(delimiter);
                skippedHeadline = true;
                continue;
            }
            ArrayList<String> tokens = new ArrayList<>(Arrays.asList(line.split(delimiter)));  // separate every token by comma
            if(line.substring(line.length() - 1).equals(delimiter)) { // Add empty string if line ends with delimiter
                tokens.add("");
            }
            Entity entity = new Entity(tokens, new ArrayList<>(Arrays.asList(headlines)));
            entities.add(entity);
        }

        return entities;
    }


}
