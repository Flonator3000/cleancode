package com.example.csvviewer1.model;

import java.util.ArrayList;

public class Entity {
    ArrayList<String> cells;
    ArrayList<String> headlines;

    public Entity(ArrayList<String> cells, ArrayList<String> headlines) {
        this.cells = cells;
        this.headlines = headlines;
    }

    public ArrayList<String> getCells() {
        return cells;
    }

    public void setCells(ArrayList<String> cells) {
        this.cells = cells;
    }

    public ArrayList<String> getHeadlines() {
        return headlines;
    }

    public void setHeadlines(ArrayList<String> headlines) {
        this.headlines = headlines;
    }
}
