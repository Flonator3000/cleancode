package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Option;

import java.util.Scanner;

public class GetNextOption {

    public static Option execute() {
        Scanner scanner = new Scanner(System.in);
        System.out.println(Option.optionsToString());
        String input = scanner.next();

        try {
            return Option.getByOptionChar(input.toUpperCase());
        } catch (IllegalArgumentException ex) {
            execute();
        }
        return null;
    }
}
