package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Option;

public class AdjustCurrentPageByOption {

    public static int execute(Option option, int currentPage, int maxPageIndex) {
        switch (option) {
            case FIRST_PAGE:
                return 0;
            case PREVIOUS_PAGE:
                return currentPage > 0 ? --currentPage : 0;
            case NEXT_PAGE:
                return currentPage < maxPageIndex ? ++currentPage : maxPageIndex;
            case LAST_PAGE:
                return maxPageIndex;
            case EXIT:
                System.exit(0);
            default:
                return 0;
        }
    }
}
