package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

public class FormatEntityList {

    public static String execute(ArrayList<Entity> entities) {

        int[] maxCharCounts = getMaxCharCounts(entities);
        String[] lines = getLines(entities, maxCharCounts);
        String output = concatLines(lines);

        return output;
    }

    private static int[] getMaxCharCounts(ArrayList<Entity> entities) {
        int columnAmount = entities.get(0).getCells().size();
        int[] maxCharCounts = new int[columnAmount];
       for (int i = 0; i<maxCharCounts.length; i++ ) {
           maxCharCounts[i] = getMaxCharCountOfColumn(entities, i);
       }
        return maxCharCounts;
    }

    private static int getMaxCharCountOfColumn(ArrayList<Entity> entities, int index) {
        int headlineLength = entities.get(0).getHeadlines().get(index).length();
        int max = entities.stream()
                .mapToInt(entity -> entity.getCells().get(index).length())
                .max()
                .orElseThrow(NoSuchElementException::new);
        return Math.max(max, headlineLength);
    }

    private static String[] getLines(ArrayList<Entity> entities, int[] maxCharCounts) {
        String[] lines = new String[entities.size() + 2];
        lines[0] = buildLine(entities.get(0).getHeadlines(), "|", " ", maxCharCounts);
        String[] seperatorLine = new String[entities.get(0).getCells().size()];
        Arrays.fill(seperatorLine, "");
        lines[1] = buildLine(new ArrayList<>(Arrays.asList(seperatorLine)), "+", "-", maxCharCounts);

        for (int i = 0; i < entities.size(); i++) {
            Entity entity = entities.get(i);
            lines[i + 2] = buildLine(entity.getCells(), "|", " ", maxCharCounts);
        }

        return lines;
    }

    private static String buildLine(ArrayList<String> strings, String separatorChar, String fillerChar, int[] maxCharCounts) {
        String line = "";

        for (int i = 0; i < strings.size(); i++) {
            line += strings.get(i);
            for (int j = strings.get(i).length(); j < maxCharCounts[i]; j++) {
                line += fillerChar;
            }
            line += separatorChar;
        }

        return line;
    }

    private static String concatLines(String[] lines) {
        return String.join("\n", lines);
    }
}
