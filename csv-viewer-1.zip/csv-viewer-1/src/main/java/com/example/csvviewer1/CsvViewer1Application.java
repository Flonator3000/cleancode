package com.example.csvviewer1;

import com.example.csvviewer1.interactor.*;
import com.example.csvviewer1.model.ExecutionParameterContainer;
import com.example.csvviewer1.model.Option;
import com.example.csvviewer1.model.Page;

import java.io.IOException;
import java.util.ArrayList;

public class CsvViewer1Application {

    public static void main(String[] args) throws IOException {
        int currentPageIndex = 0;

        ExecutionParameterContainer executionParameterContainer = ExecutionParameterContainer.getInstance(args);
        ArrayList<Page> pages = GetPages.execute(executionParameterContainer);

        while (true) {
            PrintPage.execute(pages.get(currentPageIndex));
            Option option = GetNextOption.execute();
            currentPageIndex = AdjustCurrentPageByOption.execute(option, currentPageIndex, pages.size() - 1);
        }
    }

}
