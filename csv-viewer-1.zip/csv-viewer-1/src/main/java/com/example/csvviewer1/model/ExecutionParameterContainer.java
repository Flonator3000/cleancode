package com.example.csvviewer1.model;

public class ExecutionParameterContainer {
    private static final int DEFAULT_PAGE_SIZE = 3;
    private String filePath;
    private int pageSize;


    public static ExecutionParameterContainer getInstance(String[] args) {
        ExecutionParameterContainer executionParameterContainer = new ExecutionParameterContainer();
        executionParameterContainer.setFilePath(args[0]);
        int pageSize = args.length > 1 ? Integer.parseInt(args[1]) : DEFAULT_PAGE_SIZE;
        executionParameterContainer.setPageSize(pageSize);
        return executionParameterContainer;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
