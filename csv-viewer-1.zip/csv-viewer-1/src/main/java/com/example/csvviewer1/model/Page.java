package com.example.csvviewer1.model;

import java.util.ArrayList;

public class Page {
    ArrayList<Person> persons;

    public ArrayList<Person> getPersons() {
        return persons;
    }

    public void setPersons(ArrayList<Person> persons) {
        this.persons = persons;
    }
}
