package com.example.csvviewer1.model;

import java.util.ArrayList;

public class Page {
    ArrayList<Entity> entities;

    public ArrayList<Entity> getEntities() {
        return entities;
    }

    public void setEntities(ArrayList<Entity> entities) {
        this.entities = entities;
    }
}
