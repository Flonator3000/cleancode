package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Entity;
import com.example.csvviewer1.model.ExecutionParameterContainer;
import com.example.csvviewer1.model.Page;

import java.io.IOException;
import java.util.ArrayList;

public class GetPages {

    public static ArrayList<Page> execute(ExecutionParameterContainer executionParameterContainer) throws IOException {
        ArrayList<Entity> entities = GetEntitiesFromCsv.execute(executionParameterContainer.getFilePath());
        int pageSize = executionParameterContainer.getPageSize();

        // Iterates over all entities and relates them to pages...
        ArrayList<Page> pages = new ArrayList<>();
        boolean hasMoreEntities = true;
        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            ArrayList<Entity> entitiesForNextPage = new ArrayList();
            for (int j = 0; j < pageSize; j++) {
                if (i * pageSize + j >= entities.size()) {
                    hasMoreEntities = false;
                    break;
                }
                Entity currentEntity = entities.get(i * pageSize + j);
                entitiesForNextPage.add(currentEntity);
            }
            Page page = new Page();
            page.setEntities(entitiesForNextPage);
            pages.add(page);
            if (!hasMoreEntities) {
                break;
            }
        }

        return pages;
    }
}
