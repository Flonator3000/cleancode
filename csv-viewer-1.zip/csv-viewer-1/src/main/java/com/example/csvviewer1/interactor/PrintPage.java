package com.example.csvviewer1.interactor;

import com.example.csvviewer1.model.Page;

public class PrintPage {

    public static void execute(Page page) {
        String formattedList = FormatEntityList.execute(page.getEntities());
        System.out.println(formattedList);
    }
}
